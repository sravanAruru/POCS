package com.nisum.product.controller;

import java.util.List;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
//import org.apache.activemq.broker.region.Destination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nisum.product.model.Customer;
import com.nisum.product.model.Product;
import com.nisum.product.service.CustomerService;
import com.nisum.product.service.ProductService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@Autowired
	ProductService productService;
	
	
	private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
	
	private static String subject = "ProductObj"; 

	@RequestMapping(value = "/getAllCustomers", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Customer> getAllCustomers(Model model) {

		List<Customer> listOfCustomers = customerService.getAllCustomers();
		model.addAttribute("customer", new Customer());
		model.addAttribute("listOfCustomers", listOfCustomers);
		return listOfCustomers;
	}

	
	@RequestMapping(value = "/getCustomer/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public void getCustomerById(@PathVariable int id) {
		customerService.getCustomer(id);
	}

	@RequestMapping(value = "/addCustomer", method = RequestMethod.POST, headers = "Accept=application/json")
	public Customer addCustomer(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);

	}

	@RequestMapping(value = "/addCustomer", method = RequestMethod.PUT, headers = "Accept=application/json")
	public Customer updateCustomer(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer); 

	}	

	@RequestMapping(value = "/deleteCustomer", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public void deleteCustomer(@RequestBody Customer customer) {
		customerService.deleteCustomer(customer);

	}	
	
//for active mq
		private String convertToJson(Object obj)throws JsonProcessingException {
	
	ObjectMapper objMapper=new ObjectMapper();
	String json=objMapper.writeValueAsString(obj);
	
	return json;
	
}
	//for activeMQ
	@RequestMapping(value = "/sendProduct", method = RequestMethod.POST, headers = "Accept=application/json")
	public String sendProduct(@RequestBody Product product)throws JMSException, JsonProcessingException {

		// Getting JMS connection from the server and starting it
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		Destination destination = session.createQueue(subject);
		MessageProducer producer = session.createProducer(destination);

		//System.out.println("customer josn::"+customer.getCustomerName());
		String prod=convertToJson(product);
		ObjectMessage objMessage=session.createObjectMessage(prod);
		// Here we are sending the message!
		producer.send(objMessage);
		System.out.println("Sending obj '" + objMessage.getObject()+ "'");

		connection.close();
		//save to DB
		return "successfully sent";

	}

}
