package com.nisum.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

//import com.arjuna.ats.internal.jdbc.drivers.modifiers.extensions;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {
	
	//@Autowired
	//private AccessDeniedHandler accessDeniedHandler;

		
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().requireCsrfProtectionMatcher(new AntPathRequestMatcher("**/login")).and().authorizeRequests()
		.antMatchers("/customerInfo.html").hasRole("USER")
		.and().formLogin().defaultSuccessUrl("/customerInfo.html")
		.loginPage("/login").and().logout().logoutSuccessUrl("/logout").permitAll();
				
		
	}

	// add user Roles

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("shobhan123").password("password").roles("USER").and().withUser("admin123").
		password("admin").roles("admin");
		
	}

	@Override
	public void configure(WebSecurity web) throws Exception {		
		web.ignoring().antMatchers("/*.css");
		web.ignoring().antMatchers("/*.js");
	}
}