package com.nisum.product.controller;

import java.util.List;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
//import org.apache.activemq.broker.region.Destination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.nisum.product.model.Customer;
import com.nisum.product.model.Product;
import com.nisum.product.service.CustomerService;
import com.nisum.product.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService productService;
	
	private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
	
	private static String subject = "ProductObj"; 

		@RequestMapping(value = "/home", method = RequestMethod.GET, headers = "Accept=application/json")
	public String goToHome() {
		return "redirect:/getAllProducts";
	}
	private String convertToJson(Object obj)throws JsonProcessingException {
	
	ObjectMapper objMapper=new ObjectMapper();
	objMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	objMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

	String json=objMapper.writeValueAsString(obj);
	
	return json;
	
}
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout(ModelMap model) {
		
	return "login";	
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String login(ModelMap model) {
		
	return "login";	
	}
	@RequestMapping(value = "/sendProdAddr", method = RequestMethod.POST, headers = "Accept=application/json")
	public Product sendCustomer(@RequestBody Product product)throws JMSException, JsonProcessingException {

		// Getting JMS connection from the server and starting it
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		Destination destination = session.createQueue(subject);
		MessageProducer producer = session.createProducer(destination);

		System.out.println("product josn::"+product.getProductName());
		String cust=convertToJson(product);
		ObjectMessage objMessage=session.createObjectMessage(cust);
		// Here we are sending the message!
		producer.send(objMessage);
		System.out.println("Sending obj '" + objMessage.getObject()+ "'");

		connection.close();
		//save to DB
		return productService.addProduct(product);

	}

	//for activeMQ
	@RequestMapping(value = "/sendProductInfo", method = RequestMethod.POST, headers = "Accept=application/json")
	public String sendProduct(@RequestBody Product product)throws JMSException, JsonProcessingException {
		System.out.println("in sendProduct**");
		// Getting JMS connection from the server and starting it
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
		Connection connection = connectionFactory.createConnection();
		connection.start();

		Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);

		Destination destination = session.createQueue(subject);
		MessageProducer producer = session.createProducer(destination);

		//System.out.println("customer josn::"+customer.getCustomerName());
		String prod=convertToJson(product);
		ObjectMessage objMessage=session.createObjectMessage(prod);
		// Here we are sending the message!
		producer.send(objMessage);
		System.out.println("Sending obj '" + objMessage.getObject()+ "'");

		connection.close();
		//save to DB
		return "successfully sent";

	}

}
