export class Todo{
    id:String;
    title:String;
    compleated:boolean;
    createdAt:Date;
}